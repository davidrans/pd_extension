// Settings for the RMS Enhancements content script. Served both as the
// extension's options page and as its toolbar popup. Names shared with the
// content script come from settings.js.

const form = document.getElementById('settings');
const badgeInput = document.getElementById('badge');
const status = document.getElementById('status');
const featureList = document.getElementById('features');

let statusTimer = null;
function say(message, isError) {
    status.textContent = message;
    status.classList.toggle('error', Boolean(isError));
    clearTimeout(statusTimer);
    statusTimer = setTimeout(() => { status.textContent = ''; }, 2000);
}

// One row per feature, built from the shared list.
FEATURES.forEach(feature => {
    const item = document.createElement('li');

    const label = document.createElement('label');
    label.className = 'feature';
    label.htmlFor = `feature-${feature.key}`;
    label.innerHTML = '<span class="name"></span><span class="detail"></span>';
    label.querySelector('.name').textContent = feature.name;
    label.querySelector('.detail').textContent = feature.detail;

    const toggle = document.createElement('span');
    toggle.className = 'switch';

    const input = document.createElement('input');
    input.type = 'checkbox';
    input.id = `feature-${feature.key}`;
    input.checked = true;
    input.addEventListener('change', () => {
        chrome.storage.sync.set({ [feature.key]: input.checked }, () => {
            if (chrome.runtime.lastError) say(chrome.runtime.lastError.message, true);
            else say(input.checked ? `${feature.name} on` : `${feature.name} off`);
        });
    });

    const slider = document.createElement('span');
    slider.className = 'slider';

    toggle.append(input, slider);
    item.append(label, toggle);
    featureList.appendChild(item);
});

chrome.storage.sync.get(DEFAULT_SETTINGS, stored => {
    badgeInput.value = sanitizeBadgeNumber(stored.badgeNumber) || DEFAULT_BADGE_NUMBER;
    FEATURES.forEach(feature => {
        document.getElementById(`feature-${feature.key}`).checked = stored[feature.key] !== false;
    });
});

form.addEventListener('submit', event => {
    event.preventDefault();

    const badgeNumber = sanitizeBadgeNumber(badgeInput.value);
    if (!badgeNumber) {
        say('Letters and numbers only', true);
        return;
    }

    badgeInput.value = badgeNumber;
    chrome.storage.sync.set({ badgeNumber }, () => {
        if (chrome.runtime.lastError) say(chrome.runtime.lastError.message, true);
        else say('Saved');
    });
});

// --- CONFIGURATION ---
const CASE_REGEX = /FC[0-9]+-[0-9]+/;
const REPORT_WRITER_PATH = '/axon/report-writer';
const EVIDENCE_SEARCH_PATH = '/axon/evidence-search';
const TITLE_BUTTON_CLASS = 'title-copy-btn';
const TITLE_BUTTON_LABEL = 'Copy';
const REPORT_BUTTON_LABEL = '📋 Copy Full Report';

// Evidence is checked over and anything that looks wrong is tinted red: every
// entry needs a category, and within "Case Assigned", body camera titles are
// expected to start with the badge number and IDs to be case numbers.
const FLAGGED_CLASS = 'rms-flagged';
const REQUIRED_CATEGORY = 'caseassigned';
// Accepted at the start of a title in place of the badge number.
const EXTRA_TITLE_PREFIXES = ['RNR'];
const BODY_CAM_MARKERS = ['bodyworncamera', 'axonbody'];
const REQUIRED_ID_PREFIX = 'FC';

// The evidence table is virtualised: only the rows near the viewport exist in
// the DOM, so collecting ticked rows means walking it. The default view also
// pages in more results as you near the bottom, so the walk is bounded three
// ways: to what was already loaded, to a step count, and to a time budget.
const MAX_SCROLL_STEPS = 100;
const SCROLL_SETTLE_MS = 120;
const COLLECT_BUDGET_MS = 6000;

// How long DOM changes are allowed to settle before the features re-apply.
const RERUN_DELAY_MS = 50;

// The page shows a running "N selected" summary. Read as a stopping condition:
// once that many ticked rows have been found there is no reason to keep going.
const SELECTED_COUNT_PATTERN = /^\s*(\d[\d,]*)(?:\s+\w+)?\s+selected\s*$/i;

// The site marks a ticked row on the row itself, with a generated class name of
// the form <module>__selected__<hash>. Matched on the "selected" part between
// separators, so "unselected" and the like do not count.
const SELECTED_ROW_CLASS = /(?:^|[\s_-])selected(?:[\s_-]|$)/i;

// --- SHARED HELPERS ---
function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function copyText(text) {
    return navigator.clipboard.writeText(text).catch(() => {
        // Fallback for when the async clipboard API is unavailable, or the
        // document lost focus during the scroll pass below.
        const scratch = document.createElement('textarea');
        scratch.value = text;
        scratch.style.position = 'fixed';
        scratch.style.opacity = '0';
        document.body.appendChild(scratch);
        scratch.select();
        const copied = document.execCommand('copy');
        scratch.remove();
        if (!copied) throw new Error('Copy failed');
    });
}

// Strips case, spacing and punctuation, so "Body Worn Cameras", "axonbody4"
// and "Axon Body 4" can all be matched against the same markers.
function normalize(text) {
    return String(text).toLowerCase().replace(/[^a-z0-9]/g, '');
}

// --- SETTINGS ---
// Populated from chrome.storage.sync; the defaults apply until it answers, and
// stay in force when the extension APIs aren't available at all.
const settings = Object.assign({}, DEFAULT_SETTINGS);

function badgeNumber() {
    return sanitizeBadgeNumber(settings.badgeNumber) || DEFAULT_BADGE_NUMBER;
}

function allowedPrefixPattern() {
    // One of the accepted prefixes at the start, followed by a separator rather
    // than running straight into the rest of the title.
    const prefixes = [badgeNumber(), ...EXTRA_TITLE_PREFIXES].map(sanitizeBadgeNumber);
    return new RegExp('^(?:' + prefixes.join('|') + ')(?![A-Za-z0-9])', 'i');
}

function watchSettings() {
    const storage = (typeof chrome !== 'undefined' && chrome.storage) ? chrome.storage : null;
    if (!storage || !storage.sync) return; // Fall back to the defaults.

    const load = () => storage.sync.get(DEFAULT_SETTINGS, stored => {
        Object.assign(settings, stored);
        main();
    });

    load();

    // Re-read everything rather than tracking individual keys: switching a
    // feature off has to take effect on open tabs, not just new ones.
    if (storage.onChanged) {
        storage.onChanged.addListener((changes, area) => {
            if (area === 'sync') load();
        });
    }
}

// --- FEATURE 1: Case Number Copier ---
function removeCaseNumberButtons() {
    document.querySelectorAll('.case-copy-btn').forEach(btn => btn.remove());
    document.querySelectorAll('.kvl-link-base').forEach(container => {
        delete container.dataset.hasCopyBtn;
    });
}

function handleCaseNumbers() {
    if (!settings.caseNumberCopier) {
        removeCaseNumberButtons();
        return;
    }

    const containers = document.querySelectorAll('.kvl-link-base');
    containers.forEach(container => {
        if (container.dataset.hasCopyBtn) return;
        const link = container.querySelector('a');
        if (!link) return;
        const match = link.innerText.match(CASE_REGEX);
        if (match) {
            container.dataset.hasCopyBtn = "true";

            const btn = document.createElement('button');
            btn.textContent = 'Copy';
            btn.className = 'case-copy-btn';

            btn.onclick = (e) => {
                e.preventDefault();
                e.stopPropagation();

                copyText(match[0]).then(() => {
                    btn.textContent = 'Copied!';
                    btn.classList.add('copy-success');

                    setTimeout(() => {
                        btn.textContent = 'Copy';
                        btn.classList.remove('copy-success');
                    }, 1200);
                });
            };
            container.appendChild(btn);
        }
    });
}

// --- FEATURE 2: Report Writer Copier ---
function handleReportWriter() {
    // Don't add the button if it's already there
    if (document.getElementById('master-report-copy-btn')) return;

    const btn = document.createElement('button');
    btn.id = 'master-report-copy-btn';
    btn.className = 'floating-copy-btn floating-report-copy-btn';
    btn.textContent = REPORT_BUTTON_LABEL;

    btn.onclick = () => {
        const textarea = document.getElementById('report-writer-textarea');
        if (textarea) {
            copyText(textarea.value).then(() => {
                btn.textContent = '✅ Report Copied!';
                btn.style.backgroundColor = '#007bff'; // Change to blue temporarily

                setTimeout(() => {
                    btn.textContent = REPORT_BUTTON_LABEL;
                    btn.style.backgroundColor = '';
                }, 2000);
            });
        } else {
            alert('Textarea not found! Ensure the report writer is open.');
        }
    };

    document.body.appendChild(btn);
}

// --- THE EVIDENCE TABLE ---

// The header's own text, ignoring the button we inject into it — otherwise the
// column stops being findable as soon as the button is added.
function headerLabel(cell) {
    let text = '';
    (function walk(node) {
        node.childNodes.forEach(child => {
            if (child.nodeType === Node.TEXT_NODE) {
                text += child.textContent;
            } else if (child.nodeType === Node.ELEMENT_NODE &&
                       !child.classList.contains(TITLE_BUTTON_CLASS)) {
                walk(child);
            }
        });
    })(cell);
    return text.replace(/\s+/g, ' ').trim().toLowerCase();
}

// Columns are user-configurable, so map them by header text rather than by a
// fixed position. Indexes include the leading checkbox cell, so they line up
// with the cells of each body row.
function findEvidenceTable() {
    for (const table of document.querySelectorAll('table')) {
        const headerRow = table.querySelector('thead tr');
        if (!headerRow) continue;

        const columns = new Map();
        Array.from(headerRow.children).forEach((cell, index) => {
            if (cell.getAttribute('role') === 'columnheader') {
                columns.set(headerLabel(cell), { cell, index });
            }
        });

        if (columns.has('title')) return { table, columns };
    }
    return null;
}

function findTitleColumn() {
    const found = findEvidenceTable();
    if (!found) return null;

    const title = found.columns.get('title');
    return { table: found.table, header: title.cell, index: title.index };
}

function cellText(row, index) {
    const cell = row.children[index];
    if (!cell) return '';
    // The text sits in a <p>; a title cell also holds a file-type icon.
    const text = cell.querySelector('p') || cell;
    return text.textContent.replace(/\s+/g, ' ').trim();
}

function scrollParent(el) {
    let node = el.parentElement;
    while (node && node !== document.body) {
        const overflowY = getComputedStyle(node).overflowY;
        if (/(auto|scroll)/.test(overflowY) && node.scrollHeight > node.clientHeight + 1) {
            return node;
        }
        node = node.parentElement;
    }
    return document.scrollingElement || document.documentElement;
}

// --- FEATURE 3: Evidence Title Column Copier ---

// Two signals, because the site's checkbox is a hidden input behind a drawn
// control: the input's checked property is not reliably set, but the row itself
// carries a "selected" class. Either counts.
function rowIsSelected(row) {
    const checkbox = row.querySelector('input[type="checkbox"]');
    if (checkbox && checkbox.checked) return true;

    return SELECTED_ROW_CLASS.test(row.className);
}

// Best effort: the wording is the site's, so a miss just means falling back to
// walking the loaded rows.
function selectedCount() {
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
        const match = SELECTED_COUNT_PATTERN.exec(node.textContent);
        if (match) return Number(match[1].replace(/,/g, ''));
    }
    return null;
}

async function collectSelectedTitles(table, index) {
    const scroller = scrollParent(table);
    const startingScrollTop = scroller.scrollTop;
    const found = new Map();
    let fallbackOrder = 0;

    const harvest = () => {
        table.querySelectorAll('tbody tr').forEach(row => {
            if (!rowIsSelected(row)) return;

            const title = cellText(row, index);
            if (!title) return;

            const key = row.id || title;
            if (found.has(key)) return;

            const dataIndex = Number(row.dataset.index);
            found.set(key, {
                order: Number.isFinite(dataIndex) ? dataIndex : fallbackOrder++,
                title
            });
        });
    };

    const expected = selectedCount();
    const enough = () => expected !== null && found.size >= expected;
    const deadline = Date.now() + COLLECT_BUDGET_MS;

    // What is on screen already, before disturbing anything. When the ticked
    // rows are all in view — the common case — this is the whole job.
    harvest();

    // Fixed once. The default view keeps loading more results as the bottom is
    // approached, and chasing that would scroll for as long as the list grows.
    const loadedBottom = Math.max(scroller.scrollHeight - scroller.clientHeight, 0);

    if (!enough() && scroller.scrollTop > 0) {
        // Rows above the starting position aren't in the DOM either.
        scroller.scrollTop = 0;
        await delay(SCROLL_SETTLE_MS);
        harvest();
    }

    for (let step = 0; step < MAX_SCROLL_STEPS && !enough() && Date.now() < deadline; step++) {
        const previousTop = scroller.scrollTop;
        const nextTop = Math.min(previousTop + Math.max(scroller.clientHeight - 100, 200), loadedBottom);

        if (nextTop <= previousTop) break; // Reached the end of what was loaded.

        scroller.scrollTop = nextTop;
        await delay(SCROLL_SETTLE_MS);
        harvest();

        if (scroller.scrollTop === previousTop) break; // Didn't actually move.
    }

    // Only if the walk actually moved: assigning triggers a re-render even when
    // the value is unchanged.
    if (scroller.scrollTop !== startingScrollTop) scroller.scrollTop = startingScrollTop;

    const titles = [...found.values()]
        .sort((a, b) => a.order - b.order)
        .map(entry => entry.title);

    return { titles, expected };
}

function addTitleCopyButton(header) {
    // React re-renders the header, so check the button is still in place rather
    // than trusting a one-time flag.
    if (header.querySelector('.' + TITLE_BUTTON_CLASS)) return;

    const btn = document.createElement('button');
    btn.className = TITLE_BUTTON_CLASS;
    btn.type = 'button';
    btn.textContent = TITLE_BUTTON_LABEL;
    btn.title = 'Copy the titles of the selected rows';

    btn.onclick = async (e) => {
        // The header cell also handles sorting.
        e.preventDefault();
        e.stopPropagation();

        if (btn.disabled) return;
        btn.disabled = true;
        btn.textContent = '…';

        try {
            const current = findTitleColumn();
            if (!current) throw new Error('Title column not found');

            const { titles, expected } = await collectSelectedTitles(current.table, current.index);

            if (!titles.length) {
                // Nothing ticked. Not a failure, so say so rather than going red.
                btn.textContent = 'None';
                btn.classList.add('copy-empty');
            } else {
                await copyText(titles.join('\n'));

                // Only what was already loaded gets walked, so a tick further
                // down a lazily-loaded list can be out of reach. Say so rather
                // than quietly reporting a smaller number as a success.
                const short = expected !== null && titles.length < expected;
                if (short) {
                    console.warn(`[RMS Enhancements] Copied ${titles.length} of ${expected}` +
                        ' selected rows; the rest are not loaded yet.');
                }

                btn.textContent = short ? `${titles.length}/${expected}` : `${titles.length} ✓`;
                btn.classList.add(short ? 'copy-empty' : 'copy-success');
            }
        } catch (err) {
            console.error('[RMS Enhancements] Copying titles failed:', err);
            btn.textContent = 'Failed';
            btn.classList.add('copy-failure');
        }

        setTimeout(() => {
            btn.textContent = TITLE_BUTTON_LABEL;
            btn.classList.remove('copy-success', 'copy-failure', 'copy-empty');
            btn.disabled = false;
        }, 1600);
    };

    // Sits alongside the label, ahead of the column's resize handle.
    const label = header.querySelector('div');
    (label || header).appendChild(btn);
}

// --- FEATURE 4: Flag "Case Assigned" evidence that looks wrong ---

// Source is only shown when the column has been added, so fall back to the
// title, which names the device for body camera uploads.
function isBodyCam(sourceText, titleText) {
    const text = normalize(sourceText) || normalize(titleText);
    return BODY_CAM_MARKERS.some(marker => text.includes(marker));
}

// A body camera's title should start with the badge number, or one of the
// other accepted prefixes.
function titleMissingPrefix(row, columns, startsWithAllowedPrefix) {
    const titleText = cellText(row, columns.get('title').index);
    if (!titleText) return false;

    const source = columns.get('source');
    const sourceText = source ? cellText(row, source.index) : '';
    if (!isBodyCam(sourceText, titleText)) return false;

    return !startsWithAllowedPrefix.test(titleText);
}

// Every entry should carry a case number for its ID.
function idNotACaseNumber(row, columns) {
    const id = columns.get('id');
    if (!id) return false; // Column hidden; nothing to check.

    return !cellText(row, id.index).toUpperCase().startsWith(REQUIRED_ID_PREFIX);
}

// A row that has rendered its data, as opposed to a placeholder the
// virtualised table has not filled in yet. Without this an empty skeleton row
// would briefly count as having no category.
function rowHasContent(row, columns) {
    const id = columns.get('id');
    return Boolean(cellText(row, columns.get('title').index)) ||
        Boolean(id && cellText(row, id.index));
}

function highlightProblemRows(found) {
    const columns = found.columns;
    const category = columns.get('category');
    const rows = found.table.querySelectorAll('tbody tr');

    // Without the Category column there is nothing to judge against, so leave
    // every row alone rather than guessing.
    if (!category) {
        rows.forEach(row => row.classList.remove(FLAGGED_CLASS));
        return;
    }

    const startsWithAllowedPrefix = allowedPrefixPattern();

    rows.forEach(row => {
        const categoryText = cellText(row, category.index);
        const caseAssigned = normalize(categoryText).includes(REQUIRED_CATEGORY);

        // Every entry needs a category. The other checks only apply within
        // "Case Assigned".
        const problem = (!categoryText && rowHasContent(row, columns)) || (
            caseAssigned && (
                titleMissingPrefix(row, columns, startsWithAllowedPrefix) ||
                idNotACaseNumber(row, columns)
            )
        );

        row.classList.toggle(FLAGGED_CLASS, problem);
    });
}

function removeTitleCopyButton() {
    document.querySelectorAll('.' + TITLE_BUTTON_CLASS).forEach(btn => btn.remove());
}

function clearFlags() {
    document.querySelectorAll('.' + FLAGGED_CLASS)
        .forEach(row => row.classList.remove(FLAGGED_CLASS));
}

function handleEvidenceSearch() {
    const found = findEvidenceTable();
    if (!found) return;

    if (settings.titleCopier) addTitleCopyButton(found.columns.get('title').cell);
    else removeTitleCopyButton();

    if (settings.caseAssignedChecks) highlightProblemRows(found);
    else clearFlags();
}

// --- INITIALIZATION & OBSERVER ---

// Injected buttons that live on document.body, so they survive SPA navigation
// and have to be cleaned up by hand.
const FLOATING_BUTTON_IDS = ['master-report-copy-btn'];

function removeFloatingButtons(keepId) {
    FLOATING_BUTTON_IDS.forEach(id => {
        if (id === keepId) return;
        const stale = document.getElementById(id);
        if (stale) stale.remove();
    });
}

function main() {
    const path = window.location.pathname;

    if (path.startsWith(REPORT_WRITER_PATH)) {
        if (!settings.reportCopier) {
            removeFloatingButtons();
            return;
        }
        removeFloatingButtons('master-report-copy-btn');
        handleReportWriter();
    } else if (path.startsWith(EVIDENCE_SEARCH_PATH)) {
        removeFloatingButtons();
        handleEvidenceSearch();
    } else {
        removeFloatingButtons();
        handleCaseNumbers();
    }
}

// Watch for changes (Critical for Single Page Apps). This is also what picks up
// a client-side navigation: the script is injected once per document, so moving
// between the app's pages only ever reaches us as DOM changes.
//
// Coalesced, since these pages mutate constantly while scrolling. On a timer
// rather than an animation frame: a background tab runs no frames at all, so a
// page loaded in one would sit unhandled until it was looked at.
let runQueued = false;
const observer = new MutationObserver(() => {
    if (runQueued) return;
    runQueued = true;
    setTimeout(() => {
        runQueued = false;
        main();
    }, RERUN_DELAY_MS);
});
observer.observe(document.body, { childList: true, subtree: true });

// Initial run
watchSettings();
main();

// --- CONFIGURATION ---
const CASE_NUMBER_PATTERN = /FC[0-9]+-[0-9]+/;
// The crisp.org class on the element that wraps each link. Links whose text
// has a case number get a Copy button added inside this wrapper.
const CASE_NUMBER_CLASSNAME = 'kvl-link-base';
// The crisp.org element that shows a report's Narrative, the label inside it
// that the Copy button goes next to, and the box holding the narrative text.
const NARRATIVE_FIELD_SELECTOR = 'kvl-read-only-input-vertical[data-automation-id="narrative-field"]';
const NARRATIVE_LABEL_CLASSNAME = 'kvl-read-only-input-label';
const NARRATIVE_VALUE_CLASSNAME = 'kvl-read-only-input-value';
const DRAFT_ONE_PATH = '/axon/report-writer';
// The id of the text box holding the report on the Draft One page.
const DRAFT_ONE_TEXTAREA_ID = 'report-writer-textarea';
const EVIDENCE_SEARCH_PATH = '/axon/evidence-search';

// Evidence checks. Every entry needs a category. Within "Case Assigned", body
// camera titles should start with the badge number (or one of the extra
// prefixes), and IDs should be case numbers.
const CASE_CATEGORY_NAME = 'Case Assigned';
const EXTRA_TITLE_PREFIXES = ['RNR', 'SWA'];
const BODY_CAM_TITLE_MARKER = 'Axon Body';
const CASE_ID_PREFIX = 'FC';

// --- SETTINGS ---
let settings = DEFAULT_SETTINGS;

// --- FEATURE 1: Case Number Copier ---
function caseNumberIn(container) {
    const link = container.querySelector('a');
    const match = link && link.textContent.match(CASE_NUMBER_PATTERN);
    return match ? match[0] : null;
}

function handleCaseNumbers() {
    if (!settings.caseNumberCopier) {
        document.querySelectorAll('.pd-case-copy-btn').forEach(btn => btn.remove());
        return;
    }

    document.querySelectorAll('.' + CASE_NUMBER_CLASSNAME).forEach(container => {
        const existing = container.querySelector(':scope > .pd-case-copy-btn');

        if (!caseNumberIn(container)) {
            // The link text no longer has a case number, so remove the old button.
            if (existing) existing.remove();
            return;
        }
        if (existing) return;

        const btn = document.createElement('button');
        btn.type = 'button';
        btn.textContent = 'Copy';
        btn.className = 'pd-case-copy-btn';

        btn.onclick = async (e) => {
            // Don't let the click also count as a click on the link.
            e.preventDefault();
            e.stopPropagation();

            try {
                // Read the case number when clicked, not when the button is
                // added. The site can change the link text without replacing
                // the button.
                const caseNumber = caseNumberIn(container);
                if (!caseNumber) throw new Error('No case number in the link');
                await navigator.clipboard.writeText(caseNumber);
                btn.textContent = 'Copied!';
                btn.classList.add('pd-copy-success');
            } catch (err) {
                console.error('[PD Extension] Copying the case number failed:', err);
                btn.textContent = 'Failed';
                btn.classList.add('pd-copy-failure');
            }

            setTimeout(() => {
                btn.textContent = 'Copy';
                btn.classList.remove('pd-copy-success', 'pd-copy-failure');
            }, 1200);
        };
        container.appendChild(btn);
    });
}

// --- FEATURE 2: Draft One Copier ---
function handleDraftOne() {
    if (document.querySelector('.pd-draft-one-copy-btn')) return;

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'pd-draft-one-copy-btn';
    btn.textContent = '📋 Copy Full Report';

    btn.onclick = async () => {
        const textarea = document.getElementById(DRAFT_ONE_TEXTAREA_ID);
        try {
            if (!textarea) throw new Error('No report text box on the page');
            await navigator.clipboard.writeText(textarea.value);
            btn.textContent = '✅ Report Copied!';
            btn.classList.add('pd-copy-success');
        } catch (err) {
            console.error('[PD Extension] Copying the report failed:', err);
            btn.textContent = textarea ? '⚠️ Copy failed, try again' : '⚠️ No report found';
            btn.classList.add('pd-copy-failure');
        }

        setTimeout(() => {
            btn.textContent = '📋 Copy Full Report';
            btn.classList.remove('pd-copy-success', 'pd-copy-failure');
        }, 2000);
    };

    document.body.appendChild(btn);
}

// --- THE EVIDENCE TABLE ---

// A header's text, without our buttons' text in it.
function headerLabel(cell) {
    const copy = cell.cloneNode(true);
    copy.querySelectorAll('.pd-header-btn').forEach(btn => btn.remove());
    return copy.textContent.trim().toLowerCase();
}

// Find the table that has a Title column, and map each column name to its
// header cell and position. Columns are matched by name because users can
// reorder them. Positions count the checkbox cell at the start of each row, so
// they line up with the cells in each data row.
function findEvidenceTable() {
    for (const table of document.querySelectorAll('table')) {
        const headerRow = table.querySelector('thead tr');
        if (!headerRow) continue;

        const columns = new Map();
        Array.from(headerRow.children).forEach((cell, index) => {
            if (cell.getAttribute('role') === 'columnheader') {
                columns.set(headerLabel(cell), { cell, index });
            }
        });

        if (columns.has('title')) return { table, columns };
    }
    return null;
}

function cellText(row, index) {
    // Each cell's text is in a <p>. Reading only the <p> skips the file-type
    // icon in Title cells.
    const p = row.children[index] && row.children[index].querySelector('p');
    const text = p ? p.textContent.trim() : '';
    // The site shows an empty cell as an en dash, with "No data" in hidden text
    // for screen readers. Treat the dash as empty, so missing categories and
    // IDs are caught.
    return text === '–' ? '' : text;
}

// --- FEATURE 3: Evidence Title Column Copier ---

// The site marks a ticked row with a generated class like
// "tbl__selected__c3d4". (The row's checkbox can't be used: it's a hidden
// input behind a drawn control, and its checked state isn't reliably set.)
function rowIsSelected(row) {
    return row.className.includes('__selected__');
}

// The number in the page's "3 selected" text, or null if it isn't found (for
// example, if the site changes it). The copier still works without it, but it
// can't stop scrolling early or tell you if it missed some rows. The element's
// class has a generated suffix, like "spark-lab__selectedCount__SjFC3", so only
// the stable middle part is matched.
function selectedCount() {
    const element = document.querySelector('[class*="__selectedCount__"]');
    const match = element && element.textContent.trim().match(/^([\d,]+) selected$/i);
    return match ? Number(match[1].replace(/,/g, '')) : null;
}

// The evidence table is virtualized: only the rows near the visible area exist
// in the page, so finding every ticked row means scrolling through the table.
// The default view also loads more results as you near the bottom, so the
// scroll is limited to what was already loaded, and to a time limit.
const RENDER_WAIT_MS = 120; // How long to let the site draw rows after a scroll
const TIMEOUT_MS = 6000;

// The scrollable box the table sits in. A box counts as scrollable if its
// content is taller than it is; the + 1 allows for a 1-pixel rounding
// difference, so a box that's exactly full doesn't count.
function findScrollContainer(el) {
    let node = el.parentElement;
    while (node && node !== document.body) {
        const overflowY = getComputedStyle(node).overflowY;
        if (/(auto|scroll)/.test(overflowY) && node.scrollHeight > node.clientHeight + 1) {
            return node;
        }
        node = node.parentElement;
    }
    return document.documentElement;
}

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// Every ticked row, read with readRow(row) while the row is in the page, in
// table order. readRow returns what to keep for the row, or nothing to leave
// it out. Also returns the page's own count of ticked rows, or null.
async function collectSelectedRows(table, readRow) {
    const scroller = findScrollContainer(table);
    const startingScrollTop = scroller.scrollTop;
    // Ticked rows found so far, by evidence id (the row's id), so a row seen
    // twice is only counted once. Each entry keeps the row's position in the
    // results, so rows come out in table order.
    const selectedRows = new Map();

    // Read the ticked rows that are currently in the page.
    const addSelectedRowsInViewport = () => {
        table.querySelectorAll('tbody tr').forEach(row => {
            if (!rowIsSelected(row) || selectedRows.has(row.id)) return;

            const value = readRow(row);
            if (value) selectedRows.set(row.id, { order: Number(row.dataset.index), value });
        });
    };

    const expected = selectedCount();
    const allFound = () => expected !== null && selectedRows.size >= expected;
    const deadline = Date.now() + TIMEOUT_MS;

    addSelectedRowsInViewport();

    // Note how far down the table can scroll before we start. Scrolling near the
    // bottom makes the site load more results, so the table keeps getting
    // longer. Stopping here means we only look through results that were
    // already loaded, instead of scrolling on and on.
    const loadedBottom = Math.max(scroller.scrollHeight - scroller.clientHeight, 0);

    if (!allFound() && scroller.scrollTop > 0) {
        // Rows above where you were scrolled aren't in the page either, so
        // start from the top.
        scroller.scrollTop = 0;
        await delay(RENDER_WAIT_MS);
        addSelectedRowsInViewport();
    }

    while (!allFound() && Date.now() < deadline) {
        // Scroll by one screen height minus 100px, so consecutive screens
        // overlap and no row is skipped, and by at least 200px.
        const step = Math.max(scroller.clientHeight - 100, 200);
        const previousTop = scroller.scrollTop;
        const nextTop = Math.min(previousTop + step, loadedBottom);

        if (nextTop <= previousTop) break; // Reached the end of what was loaded.

        scroller.scrollTop = nextTop;
        await delay(RENDER_WAIT_MS);
        addSelectedRowsInViewport();

        if (scroller.scrollTop === previousTop) break; // Didn't actually move.
    }

    // Put the table back where it was. Skipped if nothing moved, because setting
    // the scroll position makes the site redraw the table even when it's
    // unchanged.
    if (scroller.scrollTop !== startingScrollTop) scroller.scrollTop = startingScrollTop;

    const rows = [...selectedRows.values()]
        .sort((a, b) => a.order - b.order)
        .map(entry => entry.value);

    return { rows, expected };
}

function addTitleCopyButton(header) {
    // The site can redraw the header and drop our button, so add it back if
    // it's missing.
    if (header.querySelector('.pd-title-copy-btn')) return;

    const btn = document.createElement('button');
    btn.className = 'pd-header-btn pd-title-copy-btn';
    btn.type = 'button';
    btn.textContent = 'Copy';
    btn.title = 'Copy the titles of the selected rows';

    btn.onclick = async (e) => {
        // Clicking the header sorts the column, so don't let this click reach it.
        e.preventDefault();
        e.stopPropagation();

        if (btn.disabled) return;
        btn.disabled = true;
        btn.textContent = '…';

        try {
            const evidenceTable = findEvidenceTable();
            if (!evidenceTable) throw new Error('Title column not found');

            const { table, columns } = evidenceTable;
            const titleIndex = columns.get('title').index;
            const { rows: titles, expected } = await collectSelectedRows(table, row => cellText(row, titleIndex));

            if (expected !== null && titles.length < expected) {
                // Some ticked rows weren't loaded yet, so copying would leave
                // them out.
                throw new Error(`Found ${titles.length} of ${expected} selected rows`);
            }

            if (!titles.length) {
                // Nothing ticked. Show "None", since it isn't an error.
                btn.textContent = 'None';
                btn.classList.add('pd-copy-warning');
            } else {
                await navigator.clipboard.writeText(titles.join('\n'));
                btn.textContent = `${titles.length} ✓`;
                btn.classList.add('pd-copy-success');
            }
        } catch (err) {
            console.error('[PD Extension] Copying titles failed:', err);
            btn.textContent = 'Failed';
            btn.classList.add('pd-copy-failure');
        }

        setTimeout(() => {
            btn.textContent = 'Copy';
            btn.classList.remove('pd-copy-success', 'pd-copy-failure', 'pd-copy-warning');
            btn.disabled = false;
        }, 1600);
    };

    // Put the button next to the "Title" text, before the column's resize handle.
    header.querySelector('div').appendChild(btn);
}

// --- FEATURE 4: Evidence checks ---

function includesCaseInsensitive(text, part) {
    return text.toLowerCase().includes(part.toLowerCase());
}

// The badge number at the end of an Owner cell, like "Off. Smith, Pat (FC123)".
// Letters and digits only, since it goes into a pattern below.
const OWNER_BADGE_PATTERN = /\(([A-Za-z0-9]+)\)\s*$/;

// The row's owner's badge number, or null if the Owner column is hidden or
// doesn't show one.
function ownerBadgeNumber(row, columns) {
    const owner = columns.get('owner');
    const match = owner && cellText(row, owner.index).match(OWNER_BADGE_PATTERN);
    return match ? match[1] : null;
}

// The badge number a row's title should start with: the owner's when the Owner
// column is shown, so other people's evidence is checked against their own
// badge, and otherwise yours from the settings.
function expectedBadgeNumber(row, columns) {
    return ownerBadgeNumber(row, columns) || settings.badgeNumber;
}

// True if the title starts with the badge number or another accepted prefix,
// ignoring case. The badge number may run straight into the rest of the title,
// as long as another digit doesn't follow: "FC510 Axon Body" and
// "FC510Axon Body" pass for badge FC510, but "FC5101 Axon Body" doesn't. RNR
// and SWA must be whole words, so "SWAT" doesn't count.
function startsWithAllowedPrefix(title, badgeNumber) {
    const extras = EXTRA_TITLE_PREFIXES.join('|');
    return new RegExp(`^(${badgeNumber}(?!\\d)|(${extras})\\b)`, 'i').test(title);
}

function isCaseAssigned(row, columns) {
    const categoryText = cellText(row, columns.get('category').index);
    return includesCaseInsensitive(categoryText, CASE_CATEGORY_NAME);
}

// Every entry needs a category.
function isEvidenceMissingCategory(row, columns) {
    return !cellText(row, columns.get('category').index);
}

// A Case Assigned body cam's title should start with its owner's badge number
// (see expectedBadgeNumber), RNR or SWA. Body cam footage is recognized by "Axon Body" anywhere in the title, so
// a title with the wrong prefix is still caught. (The Source column would be
// more reliable, but it's hidden by default.)
function isBodyCamMissingBadgeNumber(row, columns) {
    if (!isCaseAssigned(row, columns)) return false;

    const title = cellText(row, columns.get('title').index);
    return includesCaseInsensitive(title, BODY_CAM_TITLE_MARKER) &&
        !startsWithAllowedPrefix(title, expectedBadgeNumber(row, columns));
}

// A case number ID and the Case Assigned category go together: an entry with
// one but not the other is wrong.
function isCaseNumberMismatched(row, columns) {
    const id = columns.get('id');
    if (!id) return false; // ID column hidden, so nothing to check.

    const hasCaseNumber = cellText(row, id.index).toUpperCase().startsWith(CASE_ID_PREFIX);
    return hasCaseNumber !== isCaseAssigned(row, columns);
}

function highlightProblemRows({ table, columns }) {

    // Without the Category column there's nothing to judge against, so flag
    // nothing rather than guess.
    if (!columns.has('category')) {
        clearFlags();
        return;
    }

    table.querySelectorAll('tbody tr').forEach(row => {
        const problem = isEvidenceMissingCategory(row, columns) ||
            isBodyCamMissingBadgeNumber(row, columns) ||
            isCaseNumberMismatched(row, columns);
        row.classList.toggle('pd-flagged', problem);
    });
}

// --- FEATURE 6: Copy + Badge ---

// Putting your badge number at the start of a title marks the evidence as
// attached to a report. This does it for the ticked rows, through the same
// request the site sends when you rename evidence yourself.

// Evidence and agency ids in a row's links, like "evidence_id=4a6f...".
const LINK_ID_PATTERN = /^[0-9a-f]{32}$/i;

// "4a6f259a60774e24..." as "4a6f259a-6077-4e24-...", the form the site's API uses.
function dashedId(id) {
    return id.replace(/^(.{8})(.{4})(.{4})(.{4})(.{12})$/, '$1-$2-$3-$4-$5');
}

// The evidence and agency ids for a row, read from its links, or null.
function evidenceIds(row) {
    const link = row.querySelector('a[href*="evidence_id="]');
    if (!link) return null;

    const params = new URL(link.href, window.location.origin).searchParams;
    const evidenceId = params.get('evidence_id') || '';
    const agencyId = params.get('partner_id') || '';
    if (!LINK_ID_PATTERN.test(evidenceId) || !LINK_ID_PATTERN.test(agencyId)) return null;

    return { evidenceId: dashedId(evidenceId), agencyId: dashedId(agencyId) };
}

// Evidence given your badge since the page loaded, by evidence id, with its
// new title. The table doesn't always show a new title until it reloads, so
// without this a second press would add the badge again.
const badgedEvidence = new Map();

// Rename one piece of evidence, the way the site does. The site's login
// cookies go with the request; the two fixed headers are ones the site sends.
// Throws unless the reply confirms the new title.
async function setEvidenceTitle({ evidenceId, agencyId }, title) {
    const response = await fetch(`/api/v1/agencies/${agencyId}/evidence/${evidenceId}/title`, {
        method: 'PATCH',
        credentials: 'same-origin',
        headers: {
            'Content-Type': 'application/json',
            'x-client-identifier': 'axon_dems_frontend',
            'x-requested-with': 'axon_fetch_openapi',
            'x-request-id': crypto.randomUUID(),
        },
        body: JSON.stringify({ data: { title } }),
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);

    const reply = await response.json();
    if (!reply || !reply.data || !reply.data.attributes || reply.data.attributes.title !== title) {
        throw new Error('the reply did not show the new title');
    }
}

// Show the new title in the row straight away, if the row is still in the
// page. Changes the existing text so the site's own redraws still work.
function showNewTitle(table, rowId, titleIndex, title) {
    const row = [...table.querySelectorAll('tbody tr')].find(tr => tr.id === rowId);
    const p = row && row.children[titleIndex] && row.children[titleIndex].querySelector('p');
    if (p && p.firstChild) p.firstChild.nodeValue = title;
}

function plural(count, word) {
    return `${count} ${word}${count === 1 ? '' : 's'}`;
}

// Copy + Badge: add your badge number to the start of the ticked titles of
// your evidence that don't already start with it (or RNR or SWA), then copy
// all the ticked titles as they now read. Titles of evidence owned by someone
// else, going by the Owner column, are copied but not changed. Nothing is
// copied if a title change fails.
async function copyAndBadgeSelectedTitles(btn) {
    const badge = settings.badgeNumber;
    if (!/^[A-Za-z0-9]+$/.test(badge || '')) {
        throw new Error('set your badge number in the extension first');
    }

    const evidenceTable = findEvidenceTable();
    if (!evidenceTable) throw new Error('the Title column was not found');
    const { table, columns } = evidenceTable;
    const titleIndex = columns.get('title').index;

    const { rows, expected } = await collectSelectedRows(table, row => ({
        rowId: row.id,
        title: cellText(row, titleIndex),
        ids: evidenceIds(row),
        owner: ownerBadgeNumber(row, columns),
    }));

    if (expected !== null && rows.length < expected) {
        // Some ticked rows weren't loaded yet, so they'd be left out.
        throw new Error(`only ${rows.length} of the ${expected} selected rows were found`);
    }
    if (!rows.length) return { label: 'None', state: 'pd-copy-warning' };
    if (rows.some(row => !row.ids || !row.title)) {
        throw new Error('the evidence id or title of a selected row could not be read');
    }

    // Each row's title as it is now, including changes made since the page
    // loaded, and whether it needs the badge.
    rows.forEach(row => {
        row.title = badgedEvidence.get(row.ids.evidenceId) || row.title;
        const mine = !row.owner || row.owner.toUpperCase() === badge.toUpperCase();
        row.needsBadge = mine && !startsWithAllowedPrefix(row.title, badge);
    });
    const toUpdate = rows.filter(row => row.needsBadge);

    if (toUpdate.length) {
        const question = `Add ${badge} to the start of ${toUpdate.length} of the ` +
            `${plural(rows.length, 'selected title')}, then copy them all?`;
        if (!window.confirm(question)) return { label: 'Cancelled', state: 'pd-copy-warning' };
    }

    // One at a time, so a problem stops at the first failure rather than
    // repeating across the whole batch.
    for (const [done, row] of toUpdate.entries()) {
        btn.textContent = `${done}/${toUpdate.length}`;
        const title = `${badge} ${row.title}`;
        try {
            await setEvidenceTitle(row.ids, title);
        } catch (err) {
            console.error('[PD Extension] Adding the badge number failed:', err);
            window.alert(`Added ${badge} to ${done} of ${plural(toUpdate.length, 'title')}, then one ` +
                `failed (${err.message}). Nothing was copied. Press Copy + Badge again to retry; ` +
                `titles already changed won't get the badge twice.`);
            return { label: 'Failed', state: 'pd-copy-failure' };
        }
        badgedEvidence.set(row.ids.evidenceId, title);
        showNewTitle(table, row.rowId, titleIndex, title);
        row.title = title;
    }

    await navigator.clipboard.writeText(rows.map(row => row.title).join('\n'));
    return { label: `${rows.length} ✓`, state: 'pd-copy-success' };
}

function addCopyAndBadgeButton(header) {
    if (header.querySelector('.pd-title-badge-btn')) return;

    const btn = document.createElement('button');
    btn.className = 'pd-header-btn pd-title-badge-btn';
    btn.type = 'button';
    btn.textContent = 'Copy + Badge';
    btn.title = 'Add your badge number to the selected titles, then copy them';

    btn.onclick = async (e) => {
        // Clicking the header sorts the column, so don't let this click reach it.
        e.preventDefault();
        e.stopPropagation();

        if (btn.disabled) return;
        btn.disabled = true;
        btn.textContent = '…';

        let result;
        try {
            result = await copyAndBadgeSelectedTitles(btn);
        } catch (err) {
            console.error('[PD Extension] Copy + Badge failed:', err);
            window.alert(`Nothing was changed or copied: ${err.message}.`);
            result = { label: 'Failed', state: 'pd-copy-failure' };
        }

        btn.textContent = result.label;
        btn.classList.add(result.state);
        setTimeout(() => {
            btn.textContent = 'Copy + Badge';
            btn.classList.remove('pd-copy-success', 'pd-copy-failure', 'pd-copy-warning');
            btn.disabled = false;
        }, 2000);
    };

    header.querySelector('div').appendChild(btn);
}

function removeTitleCopyButton() {
    document.querySelectorAll('.pd-title-copy-btn').forEach(btn => btn.remove());
}

function removeTitleBadgeButton() {
    document.querySelectorAll('.pd-title-badge-btn').forEach(btn => btn.remove());
}

function clearFlags() {
    document.querySelectorAll('.pd-flagged')
        .forEach(row => row.classList.remove('pd-flagged'));
}

function handleEvidenceSearch() {
    const evidenceTable = findEvidenceTable();
    if (!evidenceTable) {
        // No evidence table (the Title column is hidden, or the table is still
        // loading), so remove the button and any old flags.
        removeTitleCopyButton();
        removeTitleBadgeButton();
        clearFlags();
        return;
    }

    const titleHeader = evidenceTable.columns.get('title').cell;
    if (settings.titleCopier) addTitleCopyButton(titleHeader);
    else removeTitleCopyButton();

    if (settings.titleBadger) addCopyAndBadgeButton(titleHeader);
    else removeTitleBadgeButton();

    if (settings.evidenceChecks) highlightProblemRows(evidenceTable);
    else clearFlags();
}

// --- FEATURE 5: Narrative Copier ---

// The narrative as plain text, one line per paragraph. The site writes a blank
// line as a paragraph holding only a line break, so those come out as empty
// lines, matching what's on screen.
function narrativeText(value) {
    const blocks = value.querySelectorAll('p, li, h1, h2, h3, h4, h5, h6, pre, blockquote');
    if (!blocks.length) return value.textContent.trim();

    const lines = Array.from(blocks).map(block => {
        const copy = block.cloneNode(true);
        copy.querySelectorAll('br').forEach(br => br.replaceWith('\n'));
        // Drop the line break that ends a paragraph (or is all of an empty
        // one), and turn non-breaking spaces into ordinary ones.
        return copy.textContent.replace(/\n$/, '').replace(/ /g, ' ');
    });

    return lines.join('\n').trim();
}

function handleNarratives() {
    if (!settings.narrativeCopier) {
        document.querySelectorAll('.pd-narrative-copy-btn').forEach(btn => btn.remove());
        return;
    }

    document.querySelectorAll(NARRATIVE_FIELD_SELECTOR).forEach(field => {
        const label = field.querySelector('.' + NARRATIVE_LABEL_CLASSNAME);
        if (!label || label.querySelector('.pd-narrative-copy-btn')) return;

        const btn = document.createElement('button');
        btn.type = 'button';
        btn.textContent = 'Copy';
        btn.title = 'Copy the narrative';
        btn.className = 'pd-case-copy-btn pd-narrative-copy-btn';

        btn.onclick = async (e) => {
            e.preventDefault();
            e.stopPropagation();

            try {
                // Read the narrative when clicked, so it's what's on the page
                // now rather than when the button was added.
                const value = field.querySelector('.' + NARRATIVE_VALUE_CLASSNAME);
                const text = value ? narrativeText(value) : '';
                if (!text) throw new Error('No narrative text on the page');
                await navigator.clipboard.writeText(text);
                btn.textContent = 'Copied!';
                btn.classList.add('pd-copy-success');
            } catch (err) {
                console.error('[PD Extension] Copying the narrative failed:', err);
                btn.textContent = 'Failed';
                btn.classList.add('pd-copy-failure');
            }

            setTimeout(() => {
                btn.textContent = 'Copy';
                btn.classList.remove('pd-copy-success', 'pd-copy-failure');
            }, 1200);
        };
        label.appendChild(btn);
    });
}

// --- PAGE ROUTING AND STARTUP ---

// The Draft One button is attached to the page body, so it stays when you move
// to another page in the app. This removes it.
function removeDraftOneButton() {
    const btn = document.querySelector('.pd-draft-one-copy-btn');
    if (btn) btn.remove();
}

function main() {
    const path = window.location.pathname;
    const onDraftOne = path.startsWith(DRAFT_ONE_PATH);

    if (onDraftOne && settings.draftOneCopier) handleDraftOne();
    else removeDraftOneButton();

    if (path.startsWith(EVIDENCE_SEARCH_PATH)) handleEvidenceSearch();
    else if (window.location.hostname.endsWith('crisp.org')) {
        handleCaseNumbers();
        handleNarratives();
    }
}

// Re-run the features whenever the page changes. This is also how we notice
// moving to another page: the app changes pages without reloading, so we only
// see it as the page's content changing. Runs are batched to at most one every
// 50 ms, since the page changes constantly while scrolling. Text changes are
// watched too, because the site reuses rows for different evidence by changing
// only their text.
const RERUN_DELAY_MS = 50;
let runQueued = false;
const observer = new MutationObserver(() => {
    if (runQueued) return;
    runQueued = true;
    setTimeout(() => {
        runQueued = false;
        main();
    }, RERUN_DELAY_MS);
});

function applySettings(stored) {
    settings = stored;
    main();
}

// Start once the settings have loaded, so a feature that's switched off never
// shows up for a moment.
chrome.storage.sync.get(DEFAULT_SETTINGS, stored => {
    applySettings(stored);
    observer.observe(document.body, { childList: true, characterData: true, subtree: true });
});

// Re-apply whenever a setting changes, so open tabs update without a reload.
chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'sync') chrome.storage.sync.get(DEFAULT_SETTINGS, applySettings);
});

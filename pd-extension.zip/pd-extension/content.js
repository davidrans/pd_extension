// --- CONFIGURATION ---
const CASE_NUMBER_PATTERN = /FC[0-9]+-[0-9]+/;
// The crisp.org class on the element that wraps each link. Links whose text
// has a case number get a Copy button added inside this wrapper.
const CASE_NUMBER_CLASSNAME = 'kvl-link-base';
const DRAFT_ONE_PATH = '/axon/report-writer';
// The id of the text box holding the report on the Draft One page.
const DRAFT_ONE_TEXTAREA_ID = 'report-writer-textarea';
const EVIDENCE_SEARCH_PATH = '/axon/evidence-search';

// Evidence checks. Every entry needs a category. Within "Case Assigned", body
// camera titles should start with the badge number (or one of the extra
// prefixes), and IDs should be case numbers.
const CASE_CATEGORY_NAME = 'Case Assigned';
const EXTRA_TITLE_PREFIXES = ['RNR', 'SWA'];
const BODY_CAM_TITLE_MARKER = 'Axon Body';
const CASE_ID_PREFIX = 'FC';

// --- SETTINGS ---
let settings = DEFAULT_SETTINGS;

// --- FEATURE 1: Case Number Copier ---
function caseNumberIn(container) {
    const link = container.querySelector('a');
    const match = link && link.textContent.match(CASE_NUMBER_PATTERN);
    return match ? match[0] : null;
}

function handleCaseNumbers() {
    if (!settings.caseNumberCopier) {
        document.querySelectorAll('.pd-case-copy-btn').forEach(btn => btn.remove());
        return;
    }

    document.querySelectorAll('.' + CASE_NUMBER_CLASSNAME).forEach(container => {
        const existing = container.querySelector(':scope > .pd-case-copy-btn');

        if (!caseNumberIn(container)) {
            // The link text no longer has a case number, so remove the old button.
            if (existing) existing.remove();
            return;
        }
        if (existing) return;

        const btn = document.createElement('button');
        btn.type = 'button';
        btn.textContent = 'Copy';
        btn.className = 'pd-case-copy-btn';

        btn.onclick = async (e) => {
            // Don't let the click also count as a click on the link.
            e.preventDefault();
            e.stopPropagation();

            try {
                // Read the case number when clicked, not when the button is
                // added. The site can change the link text without replacing
                // the button.
                const caseNumber = caseNumberIn(container);
                if (!caseNumber) throw new Error('No case number in the link');
                await navigator.clipboard.writeText(caseNumber);
                btn.textContent = 'Copied!';
                btn.classList.add('pd-copy-success');
            } catch (err) {
                console.error('[PD Extension] Copying the case number failed:', err);
                btn.textContent = 'Failed';
                btn.classList.add('pd-copy-failure');
            }

            setTimeout(() => {
                btn.textContent = 'Copy';
                btn.classList.remove('pd-copy-success', 'pd-copy-failure');
            }, 1200);
        };
        container.appendChild(btn);
    });
}

// --- FEATURE 2: Draft One Copier ---
function handleDraftOne() {
    if (document.querySelector('.pd-draft-one-copy-btn')) return;

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'pd-draft-one-copy-btn';
    btn.textContent = '📋 Copy Full Report';

    btn.onclick = async () => {
        const textarea = document.getElementById(DRAFT_ONE_TEXTAREA_ID);
        try {
            if (!textarea) throw new Error('No report text box on the page');
            await navigator.clipboard.writeText(textarea.value);
            btn.textContent = '✅ Report Copied!';
            btn.classList.add('pd-copy-success');
        } catch (err) {
            console.error('[PD Extension] Copying the report failed:', err);
            btn.textContent = textarea ? '⚠️ Copy failed, try again' : '⚠️ No report found';
            btn.classList.add('pd-copy-failure');
        }

        setTimeout(() => {
            btn.textContent = '📋 Copy Full Report';
            btn.classList.remove('pd-copy-success', 'pd-copy-failure');
        }, 2000);
    };

    document.body.appendChild(btn);
}

// --- THE EVIDENCE TABLE ---

// A header's text, without our Copy button's text in it.
function headerLabel(cell) {
    const copy = cell.cloneNode(true);
    copy.querySelectorAll('.pd-title-copy-btn').forEach(btn => btn.remove());
    return copy.textContent.trim().toLowerCase();
}

// Find the table that has a Title column, and map each column name to its
// header cell and position. Columns are matched by name because users can
// reorder them. Positions count the checkbox cell at the start of each row, so
// they line up with the cells in each data row.
function findEvidenceTable() {
    for (const table of document.querySelectorAll('table')) {
        const headerRow = table.querySelector('thead tr');
        if (!headerRow) continue;

        const columns = new Map();
        Array.from(headerRow.children).forEach((cell, index) => {
            if (cell.getAttribute('role') === 'columnheader') {
                columns.set(headerLabel(cell), { cell, index });
            }
        });

        if (columns.has('title')) return { table, columns };
    }
    return null;
}

function cellText(row, index) {
    // Each cell's text is in a <p>. Reading only the <p> skips the file-type
    // icon in Title cells.
    const p = row.children[index] && row.children[index].querySelector('p');
    const text = p ? p.textContent.trim() : '';
    // The site shows an empty cell as an en dash, with "No data" in hidden text
    // for screen readers. Treat the dash as empty, so missing categories and
    // IDs are caught.
    return text === '–' ? '' : text;
}

// --- FEATURE 3: Evidence Title Column Copier ---

// The site marks a ticked row with a generated class like
// "tbl__selected__c3d4". (The row's checkbox can't be used: it's a hidden
// input behind a drawn control, and its checked state isn't reliably set.)
function rowIsSelected(row) {
    return row.className.includes('__selected__');
}

// The number in the page's "3 selected" text, or null if it isn't found (for
// example, if the site changes it). The copier still works without it, but it
// can't stop scrolling early or tell you if it missed some rows. The element's
// class has a generated suffix, like "spark-lab__selectedCount__SjFC3", so only
// the stable middle part is matched.
function selectedCount() {
    const element = document.querySelector('[class*="__selectedCount__"]');
    const match = element && element.textContent.trim().match(/^([\d,]+) selected$/i);
    return match ? Number(match[1].replace(/,/g, '')) : null;
}

// The evidence table is virtualized: only the rows near the visible area exist
// in the page, so finding every ticked row means scrolling through the table.
// The default view also loads more results as you near the bottom, so the
// scroll is limited to what was already loaded, and to a time limit.
const RENDER_WAIT_MS = 120; // How long to let the site draw rows after a scroll
const TIMEOUT_MS = 6000;

// The scrollable box the table sits in. A box counts as scrollable if its
// content is taller than it is; the + 1 allows for a 1-pixel rounding
// difference, so a box that's exactly full doesn't count.
function findScrollContainer(el) {
    let node = el.parentElement;
    while (node && node !== document.body) {
        const overflowY = getComputedStyle(node).overflowY;
        if (/(auto|scroll)/.test(overflowY) && node.scrollHeight > node.clientHeight + 1) {
            return node;
        }
        node = node.parentElement;
    }
    return document.documentElement;
}

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function collectSelectedTitles(table, index) {
    const scroller = findScrollContainer(table);
    const startingScrollTop = scroller.scrollTop;
    // Ticked rows found so far, by evidence id (the row's id), so a row seen
    // twice is only counted once. Each entry keeps the row's position in the
    // results, so titles come out in table order.
    const selectedRows = new Map();

    // Collect the titles of ticked rows that are currently in the page.
    const addSelectedRowsInViewport = () => {
        table.querySelectorAll('tbody tr').forEach(row => {
            if (!rowIsSelected(row)) return;

            const title = cellText(row, index);
            if (!title) return;

            if (selectedRows.has(row.id)) return;
            selectedRows.set(row.id, { order: Number(row.dataset.index), title });
        });
    };

    const expected = selectedCount();
    const allFound = () => expected !== null && selectedRows.size >= expected;
    const deadline = Date.now() + TIMEOUT_MS;

    addSelectedRowsInViewport();

    // Note how far down the table can scroll before we start. Scrolling near the
    // bottom makes the site load more results, so the table keeps getting
    // longer. Stopping here means we only look through results that were
    // already loaded, instead of scrolling on and on.
    const loadedBottom = Math.max(scroller.scrollHeight - scroller.clientHeight, 0);

    if (!allFound() && scroller.scrollTop > 0) {
        // Rows above where you were scrolled aren't in the page either, so
        // start from the top.
        scroller.scrollTop = 0;
        await delay(RENDER_WAIT_MS);
        addSelectedRowsInViewport();
    }

    while (!allFound() && Date.now() < deadline) {
        // Scroll by one screen height minus 100px, so consecutive screens
        // overlap and no row is skipped, and by at least 200px.
        const step = Math.max(scroller.clientHeight - 100, 200);
        const previousTop = scroller.scrollTop;
        const nextTop = Math.min(previousTop + step, loadedBottom);

        if (nextTop <= previousTop) break; // Reached the end of what was loaded.

        scroller.scrollTop = nextTop;
        await delay(RENDER_WAIT_MS);
        addSelectedRowsInViewport();

        if (scroller.scrollTop === previousTop) break; // Didn't actually move.
    }

    // Put the table back where it was. Skipped if nothing moved, because setting
    // the scroll position makes the site redraw the table even when it's
    // unchanged.
    if (scroller.scrollTop !== startingScrollTop) scroller.scrollTop = startingScrollTop;

    const titles = [...selectedRows.values()]
        .sort((a, b) => a.order - b.order)
        .map(entry => entry.title);

    return { titles, expected };
}

function addTitleCopyButton(header) {
    // The site can redraw the header and drop our button, so add it back if
    // it's missing.
    if (header.querySelector('.pd-title-copy-btn')) return;

    const btn = document.createElement('button');
    btn.className = 'pd-title-copy-btn';
    btn.type = 'button';
    btn.textContent = 'Copy';
    btn.title = 'Copy the titles of the selected rows';

    btn.onclick = async (e) => {
        // Clicking the header sorts the column, so don't let this click reach it.
        e.preventDefault();
        e.stopPropagation();

        if (btn.disabled) return;
        btn.disabled = true;
        btn.textContent = '…';

        try {
            const evidenceTable = findEvidenceTable();
            if (!evidenceTable) throw new Error('Title column not found');

            const { table, columns } = evidenceTable;
            const { titles, expected } = await collectSelectedTitles(table, columns.get('title').index);

            if (expected !== null && titles.length < expected) {
                // Some ticked rows weren't loaded yet, so copying would leave
                // them out.
                throw new Error(`Found ${titles.length} of ${expected} selected rows`);
            }

            if (!titles.length) {
                // Nothing ticked. Show "None", since it isn't an error.
                btn.textContent = 'None';
                btn.classList.add('pd-copy-warning');
            } else {
                await navigator.clipboard.writeText(titles.join('\n'));
                btn.textContent = `${titles.length} ✓`;
                btn.classList.add('pd-copy-success');
            }
        } catch (err) {
            console.error('[PD Extension] Copying titles failed:', err);
            btn.textContent = 'Failed';
            btn.classList.add('pd-copy-failure');
        }

        setTimeout(() => {
            btn.textContent = 'Copy';
            btn.classList.remove('pd-copy-success', 'pd-copy-failure', 'pd-copy-warning');
            btn.disabled = false;
        }, 1600);
    };

    // Put the button next to the "Title" text, before the column's resize handle.
    header.querySelector('div').appendChild(btn);
}

// --- FEATURE 4: Evidence checks ---

function includesCaseInsensitive(text, part) {
    return text.toLowerCase().includes(part.toLowerCase());
}

// True if the title starts with the badge number or another accepted prefix as
// a whole word, ignoring case. "FC510 Axon Body" passes for badge FC510, but
// "FC5101 Axon Body" doesn't.
function startsWithAllowedPrefix(title) {
    const prefixes = [settings.badgeNumber, ...EXTRA_TITLE_PREFIXES].join('|');
    return new RegExp(`^(${prefixes})\\b`, 'i').test(title);
}

function isCaseAssigned(row, columns) {
    const categoryText = cellText(row, columns.get('category').index);
    return includesCaseInsensitive(categoryText, CASE_CATEGORY_NAME);
}

// Every entry needs a category.
function isEvidenceMissingCategory(row, columns) {
    return !cellText(row, columns.get('category').index);
}

// A Case Assigned body cam's title should start with the badge number, RNR or
// SWA. Body cam footage is recognized by "Axon Body" anywhere in the title, so
// a title with the wrong prefix is still caught. (The Source column would be
// more reliable, but it's hidden by default.)
function isBodyCamMissingBadgeNumber(row, columns) {
    if (!isCaseAssigned(row, columns)) return false;

    const title = cellText(row, columns.get('title').index);
    return includesCaseInsensitive(title, BODY_CAM_TITLE_MARKER) && !startsWithAllowedPrefix(title);
}

// A Case Assigned entry's ID should be a case number.
function isEvidenceMissingCaseNumber(row, columns) {
    const id = columns.get('id');
    if (!id) return false; // ID column hidden, so nothing to check.
    if (!isCaseAssigned(row, columns)) return false;

    return !cellText(row, id.index).toUpperCase().startsWith(CASE_ID_PREFIX);
}

function highlightProblemRows({ table, columns }) {

    // Without the Category column there's nothing to judge against, so flag
    // nothing rather than guess.
    if (!columns.has('category')) {
        clearFlags();
        return;
    }

    table.querySelectorAll('tbody tr').forEach(row => {
        const problem = isEvidenceMissingCategory(row, columns) ||
            isBodyCamMissingBadgeNumber(row, columns) ||
            isEvidenceMissingCaseNumber(row, columns);
        row.classList.toggle('pd-flagged', problem);
    });
}

function removeTitleCopyButton() {
    document.querySelectorAll('.pd-title-copy-btn').forEach(btn => btn.remove());
}

function clearFlags() {
    document.querySelectorAll('.pd-flagged')
        .forEach(row => row.classList.remove('pd-flagged'));
}

function handleEvidenceSearch() {
    const evidenceTable = findEvidenceTable();
    if (!evidenceTable) {
        // No evidence table (the Title column is hidden, or the table is still
        // loading), so remove the button and any old flags.
        removeTitleCopyButton();
        clearFlags();
        return;
    }

    if (settings.titleCopier) addTitleCopyButton(evidenceTable.columns.get('title').cell);
    else removeTitleCopyButton();

    if (settings.evidenceChecks) highlightProblemRows(evidenceTable);
    else clearFlags();
}

// --- PAGE ROUTING AND STARTUP ---

// The Draft One button is attached to the page body, so it stays when you move
// to another page in the app. This removes it.
function removeDraftOneButton() {
    const btn = document.querySelector('.pd-draft-one-copy-btn');
    if (btn) btn.remove();
}

function main() {
    const path = window.location.pathname;
    const onDraftOne = path.startsWith(DRAFT_ONE_PATH);

    if (onDraftOne && settings.draftOneCopier) handleDraftOne();
    else removeDraftOneButton();

    if (path.startsWith(EVIDENCE_SEARCH_PATH)) handleEvidenceSearch();
    else if (window.location.hostname.endsWith('crisp.org')) handleCaseNumbers();
}

// Re-run the features whenever the page changes. This is also how we notice
// moving to another page: the app changes pages without reloading, so we only
// see it as the page's content changing. Runs are batched to at most one every
// 50 ms, since the page changes constantly while scrolling. Text changes are
// watched too, because the site reuses rows for different evidence by changing
// only their text.
const RERUN_DELAY_MS = 50;
let runQueued = false;
const observer = new MutationObserver(() => {
    if (runQueued) return;
    runQueued = true;
    setTimeout(() => {
        runQueued = false;
        main();
    }, RERUN_DELAY_MS);
});

function applySettings(stored) {
    settings = stored;
    main();
}

// Start once the settings have loaded, so a feature that's switched off never
// shows up for a moment.
chrome.storage.sync.get(DEFAULT_SETTINGS, stored => {
    applySettings(stored);
    observer.observe(document.body, { childList: true, characterData: true, subtree: true });
});

// Re-apply whenever a setting changes, so open tabs update without a reload.
chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'sync') chrome.storage.sync.get(DEFAULT_SETTINGS, applySettings);
});

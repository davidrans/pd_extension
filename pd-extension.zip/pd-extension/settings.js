// Shared by the content script and the options page. Loaded first in both, so
// these names are available to the scripts that follow.

const DEFAULT_BADGE_NUMBER = 'FC510';

// The order here is the order shown in the options page.
const FEATURES = [
    {
        key: 'caseNumberCopier',
        name: 'Case number copier',
        detail: 'A Copy button beside case numbers on crisp.org.',
    },
    {
        key: 'reportCopier',
        name: 'Report writer copier',
        detail: 'A button that copies the whole report writer draft.',
    },
    {
        key: 'titleCopier',
        name: 'Evidence title copier',
        detail: 'A Copy button on the Title column header.',
    },
    {
        // Key kept as-is so an existing stored preference is not reset; the
        // checks have since grown beyond the "Case Assigned" category.
        key: 'caseAssignedChecks',
        name: 'Evidence checks',
        detail: 'Tints a row red when its category, title or ID looks wrong.',
    },
];

// Every feature is on unless it has been switched off.
const DEFAULT_SETTINGS = FEATURES.reduce(
    (defaults, feature) => Object.assign(defaults, { [feature.key]: true }),
    { badgeNumber: DEFAULT_BADGE_NUMBER });

function sanitizeBadgeNumber(value) {
    return String(value == null ? '' : value).replace(/[^A-Za-z0-9]/g, '');
}

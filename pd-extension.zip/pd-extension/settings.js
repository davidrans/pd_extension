// Settings shared by the popup and the content script. Loaded before
// options.js in the popup and before content.js on the work sites, so both can
// use these names.

const DEFAULT_BADGE_NUMBER = 'FC510';

// The order here is the order shown in the options page.
const FEATURES = [
    {
        key: 'caseNumberCopier',
        name: 'Case number copier',
        detail: 'A Copy button beside case numbers on crisp.org.',
    },
    {
        key: 'draftOneCopier',
        name: 'Draft One copier',
        detail: 'A button that copies the whole Draft One report.',
    },
    {
        key: 'titleCopier',
        name: 'Evidence title copier',
        detail: 'A Copy button on the Title column header.',
    },
    {
        key: 'evidenceChecks',
        name: 'Evidence checks',
        detail: 'Tints a row red when its category, title or ID looks wrong.',
    },
];

// Every feature starts switched on.
const DEFAULT_SETTINGS = { badgeNumber: DEFAULT_BADGE_NUMBER };
for (const feature of FEATURES) {
    DEFAULT_SETTINGS[feature.key] = true;
}

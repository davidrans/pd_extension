// The settings page, shown both as the toolbar popup and as the extension's
// options page. FEATURES and DEFAULT_SETTINGS come from settings.js.

const form = document.getElementById('settings');
const badgeInput = document.getElementById('badge');
const status = document.getElementById('status');
const featureList = document.getElementById('features');

let statusTimer = null;
function showStatus(message, isError) {
    status.textContent = message;
    status.classList.toggle('error', Boolean(isError));
    clearTimeout(statusTimer);
    statusTimer = setTimeout(() => { status.textContent = ''; }, 2000);
}

// FEATURES is our own list, so its text is safe to put into HTML.
featureList.innerHTML = FEATURES.map(feature => `
    <li>
      <label>
        <input type="checkbox" name="${feature.key}">
        <span>${feature.name}<span class="detail">${feature.detail}</span></span>
      </label>
    </li>`).join('');

// One listener for all the feature checkboxes.
featureList.addEventListener('change', ({ target }) => {
    const feature = FEATURES.find(f => f.key === target.name);
    chrome.storage.sync.set({ [feature.key]: target.checked }, () => {
        if (chrome.runtime.lastError) showStatus(chrome.runtime.lastError.message, true);
        else showStatus(`${feature.name} ${target.checked ? 'on' : 'off'}`);
    });
});

chrome.storage.sync.get(DEFAULT_SETTINGS, stored => {
    badgeInput.value = stored.badgeNumber;
    FEATURES.forEach(feature => {
        featureList.querySelector(`[name="${feature.key}"]`).checked = stored[feature.key];
    });
});

form.addEventListener('submit', event => {
    event.preventDefault();
    chrome.storage.sync.set({ badgeNumber: badgeInput.value }, () => {
        if (chrome.runtime.lastError) showStatus(chrome.runtime.lastError.message, true);
        else showStatus('Saved');
    });
});
